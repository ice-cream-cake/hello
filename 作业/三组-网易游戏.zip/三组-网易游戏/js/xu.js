
	// 第一个图片区
$(function(){
        $("#dd>ul>li").mouseenter(function () {
            $(this).children('i').stop().animate({width:50},100,"linear");
            return false;
        });
        $("#dd>ul>li").mouseleave(function () {
            $(this).children('i').stop().animate({width:20},100,"linear");
            return false;
        });

    });
