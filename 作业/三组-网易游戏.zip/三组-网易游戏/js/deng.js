$(function(){
	// 展开收起
	$('.game .game-more').click(function(){
		$('.game-box .game-box-left-block1 > ul').slideToggle();
		$('.game-box .game-box-left-block2 > ul').slideToggle();
		$('.game-box .game-box-right-block1 > ul').slideToggle();
		$('.game-box .game-box-right-block2 > ul').slideToggle();
		$('.game-box').css("height","110px");
		$('.game').css("height","210px");
     	$('.game-more').css("display","none");
     	$('.game-hide').css("display","block");
  			
     });
	$('.game .game-hide').click(function(){
		$('.game-box .game-box-left-block1 > ul').slideToggle();
		$('.game-box .game-box-left-block2 > ul').slideToggle();
		$('.game-box .game-box-right-block1 > ul').slideToggle();
		$('.game-box .game-box-right-block2 > ul').slideToggle();
		$('.game-box').css("height","400px");
		$('.game').css("height","550px");
     	$('.game-hide').css("display","none");
     	$('.game-more').css("display","block");
  			
     });
});