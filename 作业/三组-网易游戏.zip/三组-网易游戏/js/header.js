// 背景图渐变轮播
$(function () {
	//事件模块
	var mytop=100;
	var sx=0;
	var speed=800
	var timer=null;

	$('.headerctrl ol li').click(function(e) {
		mytop++
		//角标的工作应用类样式;
        $(this).addClass('current').siblings().removeClass()
		
		//图片的工作跟角标对应显示；
		var index=$(this).index();
		$('.headerpic ul li').eq(index).css('z-index',mytop).hide().fadeIn()
		//$('.all ul li').eq(index).css({zIndex:num}).hide().fadeIn(speed);
		sx=index;
    });
	

	//自动播放模块
	timer=setInterval(autoplay,2000)
	function autoplay(){
		mytop++
		sx++
		if(sx>4){sx=0}
		$('.headerctrl ol li').eq(sx).addClass('current').siblings().removeClass();
		$('.headerpic ul li').eq(sx).css({zIndex:mytop}).hide().fadeIn(speed);
		$('.prevbox > div').eq(sx).addClass('curre').removeClass('currno').siblings().addClass('currno').removeClass('curre');
		$('.nextbox > div').eq(sx).addClass('curre').removeClass('currno').siblings().addClass('currno').removeClass('curre');
	}
	
	//箭头工作
	$('.header .rightctrl').click(function(e) {
        sx++;
		mytop++;
		if(sx>4){sx=0}
		//都有谁需要跟着这个顺序走。
		$('.headerctrl ol li').eq(sx).addClass('current').siblings().removeClass();//角标
		
		$('.headerpic ul li').eq(sx).css({zIndex:mytop}).hide().fadeIn(speed);
    });
	
	$('.header .leftctrl').click(function(e) {
        sx--;
		mytop++;
		if(sx<0){sx=4}
		//都有谁需要跟着这个顺序走。
		$('.headerctrl ol li').eq(sx).addClass('current').siblings().removeClass();
		
		$('.headerpic ul li').eq(sx).css({zIndex:mytop}).hide().fadeIn(speed);

    });

	
	//鼠标移上停止定时器模块
	$('.headerpic').hover(function(e) {
        //停止自动播放，清除定时器；
		clearInterval(timer)
    },function(e){
		clearInterval(timer)
		timer=setInterval(autoplay,2000)
    });

    //两边箭头弹出块
    $('.header .leftctrl').mouseenter(function(){
    	$('.header .leftctrl').css("background","#3c3d3f");
    	$('.header .prevbox').show();
    });
     $('.header .leftctrl').mouseleave(function(){
     	$('.header .leftctrl').css("background","#cf0f32");
     	$('.header .prevbox').hide();
     });

      $('.header .rightctrl').mouseenter(function(){
    	$('.header .rightctrl').css("background","#3c3d3f");
    	$('.header .nextbox').show();
    });
     $('.header .rightctrl').mouseleave(function(){
     	$('.header .rightctrl').css("background","#cf0f32");
     	$('.header .nextbox').hide();
     });

     // 游戏列表模块
     $('.topbar .topopen').click(function(){
     	$('.topbox .topnav').slideToggle();
     	$('.topbar .topopen').css("display","none");
     	$('.topbar .topclose').css("display","block");
     });
     $('.button_close').click(function(){
     	$('.topnav').slideToggle();
     	$('.topbar .topclose').css("display","none");
     	$('.topbar .topopen').css("display","block");
     });
     $('.topbar .topclose').click(function(){
     	$('.topbox .topnav').slideToggle();
     	$('.topbar .topclose').css("display","none");
     	$('.topbar .topopen').css("display","block");
     });


     // 下面新闻区域
     $("#coo>a").mouseenter(function(){
            // $(this).prev().show().end().parent().siblings().children("img").hide();
            $(this).css("background","black").children("i").addClass("triangle").end().siblings().css("background","none").children("i").removeClass("triangle");
        });
        $("#coo>a").click(function(){
            idx=$(this).index()+1;
            $("#mmg").attr("src",'rimg/play'+idx+'.jpg');
            return false;
        });
        $("#coo>a").mouseleave(function(){
            $(this).eq(idx).css("background","black").children("i").addClass("triangle");
        });
});




