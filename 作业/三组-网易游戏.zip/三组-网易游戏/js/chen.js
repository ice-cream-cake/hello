$(function(){
// 换一换区
	var index = 0;
	function changeOther() {
		$('.hot-box').eq(index).siblings('div').css({"display":"none"});
		$('.hot-box').eq(index).css({"display":"block"});
		$('.hot-box-cont').slideToggle();
		$('.hot-box-cont').slideToggle();
		$('.changeOther')[0].style.transition = "0.3s linear";
        $('.changeOther')[0].style.transform = "rotate("+ 360 * index +"deg)";
	}
	$('.change').click(function () {
		if(index < 2){
			index ++;
		}
		else{
			index = 0;
		}
		changeOther();
	});


});
