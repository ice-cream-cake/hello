$(function(){

	$('.side .side_close').click(function(){
		$('.side').css('display','none');
		$('.sidebody').css('display','none');
	});
	// 移动了就更新最近一次移动的时间。
	var timer = null;
	// $('body').onmousemove = function(){
	// 	clearInterval(timer);
	// 	window.lastMove = new Date().getTime();
	// 	};
	// 	window.lastMove = new Date().getTime();//最近一次移动时间
	// 	window.setInterval(function(){//每1秒钟检查一次。
	// 	var now = new Date().getTime();
	// 	// 如果超时了
	// 	if( now - lastMove > 10000){
	// 	// 		console.log(11);
	// 	// 		$('.side').css('display','none');
	// 	// 		$('.sidebody').css('display','none');
	// 	// }else{
	// 		$('.side').css('display','block');
	// 		$('.sidebody').css('display','block');
	// 		clearInterval(timer);
	// 	}
	// }, 5000); 
	// 
	// var timer;  
    var hidding = false;  
    $('body').mousemove(function () {  
        if(hidding){  
          hidding = false;  
          return;  
        }  
            if (timer) {  
                clearTimeout(timer);  
                timer = 0;  
            }  
    //         $('.side').css('display','none');
	 		// $('.sidebody').css('display','none'); 
	 		console.log(11);
        timer = setTimeout(function () {  
        hidding = true;  
            $('.side').css('display','block');
	 		$('.sidebody').css('display','block');
	 		console.log(12);
        }, 30000)
    });  
});
